<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta property="og:image" content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHiFHseXDz3LwKUGbgiWkKq0Aqrtk0X6a1Vw&usqp=CAU">
    <meta name="theme-color" content="#478ac9">
    <meta name="description"content="Lisa Olivia"
        <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="dist/sweetalert2.min.css">
     <script src="dist/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 
        <title>Chat Netizen</title>
        
        <link rel="stylesheet" href="http://cdn.jsdelivr.net/emojione/1.3.0/assets/css/emojione.min.css"/>
        <link rel="stylesheet" href="./assets/css/styles.css" />

    </head>
    
    <body>

        <div class="shoutbox">
            
            <h1>Chat Netizen<img src='./assets/img/refresh.png'/></h1>
            
            <ul class="shoutbox-content"></ul>
            
            <div class="shoutbox-form">
                <h2>Tulis Pesan <span>×</span></h2>
                
                <form action="./publish.php" method="post">
                    <label for="shoutbox-name">Nama </label> <input type="text" id="shoutbox-name" name="name"/>
                    <label class="shoutbox-comment-label" for="shoutbox-comment">Pesan </label> <textarea id="shoutbox-comment" name="comment" maxlength='240'></textarea>
                    <input type="submit" value="Kirim"/>
                </form>
            </div>
            
        </div>

        <footer>
            <a class="tz" href="/">Me: Lisa Olivia</a>
            <div id="tzine-actions"></div>
            <span class="close">✕</span>
        </footer>

        <!-- Include jQuery and the EmojiOne library -->
        <script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
        <script src="http://cdn.jsdelivr.net/emojione/1.3.0/lib/js/emojione.min.js"></script>
        <script src="./assets/js/script.js"></script>

    </body>
    
</html>